#include "ring.h"

void Ring::genVertices() {
	glm::mat4 rotate = glm::rotate(glm::mat4(1.0f), glm::radians(360.0f / float(n)), glm::vec3(0.0f, 0.0f, 1.0f));

	/* Upper ring outer circle vertices */
	glm::vec4 vectorOuterTop(0.0f, outerRadius, height / 2.0f, 1.0f);
	glm::vec4 transformedVectorOuterTop = vectorOuterTop;
	vertices.push_back(vectorOuterTop);
	for (int i = 1; i < n; ++i) {
		transformedVectorOuterTop = rotate * transformedVectorOuterTop;
		vertices.push_back(transformedVectorOuterTop);
	}
	/* Upper ring inner circle vertices */
	glm::vec4 vectorInnerTop(0.0f, innerRadius, height / 2.0f, 1.0f);
	glm::vec4 transformedVectorInnerTop = vectorInnerTop;
	vertices.push_back(vectorInnerTop);
	for (int i = 1; i < n; ++i) {
		transformedVectorInnerTop = rotate * transformedVectorInnerTop;
		vertices.push_back(transformedVectorInnerTop);
	}
	/* Lower ring outer circle vertices */
	glm::vec4 vectorOuterBottom(0.0f, outerRadius, -height / 2.0f, 1.0f);
	glm::vec4 transformedVectorOuterBottom = vectorOuterBottom;
	vertices.push_back(vectorOuterBottom);
	for (int i = 1; i < n; ++i) {
		transformedVectorOuterBottom = rotate * transformedVectorOuterBottom;
		vertices.push_back(transformedVectorOuterBottom);
	}
	/* Lower ring inner circle vertices */
	glm::vec4 vectorInnerBottom(0.0f, innerRadius, -height / 2.0f, 1.0f);
	glm::vec4 transformedVectorInnerBottom = vectorInnerBottom;
	vertices.push_back(vectorInnerBottom);
	for (int i = 1; i < n; ++i) {
		transformedVectorInnerBottom = rotate * transformedVectorInnerBottom;
		vertices.push_back(transformedVectorInnerBottom);
	}
}

void Ring::genIndices() {
	/* Upper ring indices*/
	for (int i = 0; i < n - 1; ++i) {
		indices.push_back(i);
		indices.push_back(i + n);
		indices.push_back(i + 1);
		indices.push_back(i + 1);
		indices.push_back(i + n);
		indices.push_back(i + n + 1);
	}
	indices.push_back(n - 1);
	indices.push_back(2 * n - 1);
	indices.push_back(0);
	indices.push_back(0);
	indices.push_back(2 * n - 1);
	indices.push_back(n);
	/* Lower ring indices*/
	for (int i = 2 * n; i < 3 * n - 1; ++i) {
		indices.push_back(i);
		indices.push_back(i + n);
		indices.push_back(i + 1);
		indices.push_back(i + 1);
		indices.push_back(i + n);
		indices.push_back(i + n + 1);
	}
	indices.push_back(3 * n - 1);
	indices.push_back(4 * n - 1);
	indices.push_back(2 * n);
	indices.push_back(2 * n);
	indices.push_back(4 * n - 1);
	indices.push_back(3 * n);
	/* */
	for (int i = 0; i < n - 1; ++i) {
		indices.push_back(i);
		indices.push_back(i + 2 * n);
		indices.push_back(i + 1);
		indices.push_back(i + 1);
		indices.push_back(i + 2 * n);
		indices.push_back(i + 2 * n + 1);
	}
	indices.push_back(n - 1);
	indices.push_back(3 * n - 1);
	indices.push_back(0);
	indices.push_back(0);
	indices.push_back(3 * n - 1);
	indices.push_back(2 * n);
	/* */
	for (int i = 0; i < n - 1; ++i) {
		indices.push_back(i + n);
		indices.push_back(i + 3 * n);
		indices.push_back(i + 1 + n);
		indices.push_back(i + 1 + n);
		indices.push_back(i + 3 * n);
		indices.push_back(i + 3 * n + 1);
	}
	indices.push_back(2 * n - 1);
	indices.push_back(4 * n - 1);
	indices.push_back(n);
	indices.push_back(n);
	indices.push_back(4 * n - 1);
	indices.push_back(3 * n);
}

Ring::Ring(float innerRadius, float outerRadius, float height) {
	this->innerRadius = innerRadius;
	this->outerRadius = outerRadius;
	this->height = height;
	this->width = 2 * outerRadius;
	this->depth = 2 * outerRadius;
	genVertices();
	genIndices();
	for (auto i = 0; i < vertices.size() / 2; ++i) {
		colors.push_back(glm::vec3(1.0f, 0.0f, 0.0f));
		colors.push_back(glm::vec3(0.0f, 0.0f, 1.0f));
	}
	// for (auto i = 0; i < vertices.size() / 4; ++i) {
	// 	colors.push_back(glm::vec3(0.0f, 0.0f, 1.0f));
	// }
	// for (auto i = 0; i < vertices.size() / 4; ++i) {
	// 	colors.push_back(glm::vec3(1.0f, 0.0f, 0.0f));
	// }
	// for (auto i = 0; i < vertices.size() / 4; ++i) {
	// 	colors.push_back(glm::vec3(0.0f, 0.0f, 1.0f));
	// }
	rotate(-90.0f, 0.0f, 0.0f);
}

Ring::~Ring() {

}

float Ring::getOuterRadius() {
	return outerRadius;
}

float Ring::getInnerRadius() {
	return innerRadius;
}
